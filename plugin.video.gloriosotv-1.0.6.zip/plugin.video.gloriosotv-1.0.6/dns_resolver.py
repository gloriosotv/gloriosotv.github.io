import xbmcaddon
import socket
import random
import struct
import sys
import logging
import ssl

# Configura log
logging.basicConfig(level=logging.DEBUG, format='[DoT] %(message)s')

class DNSOverTLS(object):
    def __init__(self, dns_server="1.1.1.1"):
        self.dns_server = xbmcaddon.Addon().getSetting("enderecodns") or dns_server
        self.sni_hostname = self.detect_sni(self.dns_server)
        self.PY2 = sys.version_info[0] == 2
        self.original_getaddrinfo = socket.getaddrinfo
        self.cache = {}
        self.debug_mode = False
        socket.getaddrinfo = self._resolver

    def detect_sni(self, ip):
        sni_map = {
            #"1.1.1.1": "cloudflare-dns.com",
            #"8.8.8.8": "dns.google",
            #"9.9.9.9": "dns.quad9.net",
            #"94.140.14.14": "dns.adguard.com",
            #"45.90.28.155": "dns.nextdns.io",
            "45.90.28.174": "cecc87.dns.nextdns.io"
        }
        return sni_map.get(ip, ip)  # fallback para o próprio IP como SNI

    def bchr(self, val):
        return chr(val) if self.PY2 else bytes([val])

    def bjoin(self, parts):
        return b"".join(parts)

    def to_bytes(self, val):
        if self.PY2:
            return val if isinstance(val, str) else val.encode("utf-8")
        return val if isinstance(val, bytes) else val.encode("utf-8")

    def is_valid_ipv4(self, ip):
        try:
            socket.inet_aton(ip)
            return True
        except socket.error:
            return False

    def resolve(self, domain):
        if domain in self.cache:
            logging.debug("Cache hit: %s -> %s" % (domain, self.cache[domain]))
            return self.cache[domain]

        def build_query(domain):
            tid = random.randint(0, 65535)
            header = struct.pack(">HHHHHH", tid, 0x0100, 1, 0, 0, 0)
            qname_parts = []
            for part in domain.split('.'):
                qname_parts.append(self.bchr(len(part)))
                qname_parts.append(self.to_bytes(part))
            qname_parts.append(self.bchr(0))
            qname = self.bjoin(qname_parts)
            question = qname + struct.pack(">HH", 1, 1)
            return header + question, tid

        def parse_response(data, tid):
            if len(data) < 12 or struct.unpack(">H", data[:2])[0] != tid:
                return None
            answer_count = struct.unpack(">H", data[6:8])[0]
            offset = 12
            while offset < len(data) and (ord(data[offset]) if self.PY2 else data[offset]) != 0:
                offset += 1
            offset += 5
            for _ in range(answer_count):
                if offset + 10 >= len(data):
                    return None
                offset += 2
                type_, class_, ttl, rdlen = struct.unpack(">HHIH", data[offset:offset+10])
                offset += 10
                if type_ == 1 and class_ == 1 and rdlen == 4:
                    ip = ".".join(str(ord(c)) if self.PY2 else str(c) for c in data[offset:offset+4])
                    self.cache[domain] = ip
                    logging.debug("Resolved: %s -> %s" % (domain, ip))
                    return ip
                offset += rdlen
            return None

        try:
            query, tid = build_query(domain)
            context = ssl.create_default_context()
            with socket.create_connection((self.dns_server, 853), timeout=5) as sock:
                with context.wrap_socket(sock, server_hostname=self.sni_hostname) as ssock:
                    ssock.sendall(struct.pack(">H", len(query)) + query)
                    resp_len = struct.unpack(">H", ssock.recv(2))[0]
                    data = ssock.recv(resp_len)
                    return parse_response(data, tid)
        except Exception as e:
            logging.error("Erro ao resolver %s via DoT: %s" % (domain, e))
            return None

    def _resolver(self, host, port, *args, **kwargs):
        try:
            if self.is_valid_ipv4(host):
                logging.debug("Bypass: %s é IP" % host)
                return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (host, port))]
            ip = self.resolve(host)
            if ip:
                return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (ip, port))]
            if not self.debug_mode:
                logging.warning("Fallback para getaddrinfo original: %s" % host)
                return self.original_getaddrinfo(host, port, *args, **kwargs)
        except Exception as e:
            logging.error("Erro no _resolver para %s: %s" % (host, e))
        return self.original_getaddrinfo(host, port, *args, **kwargs)

