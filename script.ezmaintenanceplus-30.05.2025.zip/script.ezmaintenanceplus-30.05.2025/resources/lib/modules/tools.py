"""
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs, os, sys
import urllib
import re
import time
import zipfile
from math import trunc
from resources.lib.modules import control
from datetime import datetime
from resources.lib.modules.backtothefuture import unicode, PY2

if PY2:
    FancyURLopener = urllib.FancyURLopener
    translatePath = xbmc.translatePath
else:
    FancyURLopener = urllib.request.FancyURLopener
    translatePath = xbmcvfs.translatePath

dp           = xbmcgui.DialogProgress()
dialog       = xbmcgui.Dialog()
addonInfo    = xbmcaddon.Addon().getAddonInfo

AddonTitle="EZ Maintenance+"
AddonID ='script.ezmaintenanceplus'

def xml_data_advSettings_New(memorysize, curlclienttimeout, curllowspeedtime, curlretries, tcptimeout, buffermode, readfactor):
    xml_data = """<advancedsettings>
  <network>
    <curlclienttimeout>%s</curlclienttimeout>
    <curllowspeedtime>%s</curllowspeedtime>
    <curlretries>%s</curlretries>
    <tcptimeout>%s</tcptimeout>
  </network>
  <cache>
    <memorysize>%s</memorysize>
    <buffermode>%s</buffermode>
    <readfactor>%s</readfactor>
  </cache>
</advancedsettings>""" % (
        curlclienttimeout, curllowspeedtime, curlretries, tcptimeout,
        memorysize, buffermode, readfactor
    )
    return xml_data

def advancedSettings():
    XML_FILE = translatePath(os.path.join('special://home/userdata', 'advancedsettings.xml'))
    FREEMEM = xbmc.getInfoLabel("System.FreeMemory")
    TOTALMEM = xbmc.getInfoLabel("System.Memory(total)")

    try:
        free_mem = int(re.sub('[^0-9]', '', FREEMEM))  # em MB
        total_mem = int(re.sub('[^0-9]', '', TOTALMEM))  # em MB
    except:
        dialog.ok(AddonTitle, "Erro ao obter memória do sistema.")
        return

    memorysize = trunc((free_mem / 3) * 1024 * 1024)

    # Detecta núcleos da CPU (Linux/Android)
    cpu_cores = 1  # padrão
    try:
        if os.path.exists("/proc/cpuinfo"):
            with open("/proc/cpuinfo", "r") as f:
                cpuinfo = f.read()
                cpu_cores = cpuinfo.count("processor\t:")
    except:
        pass

    # Classificação do desempenho
    if cpu_cores <= 2 or total_mem <= 1500:
        buffermode = 1
        readfactor = 5
        tcptimeout = 20
    elif 2 < cpu_cores <= 4 or total_mem <= 3000:
        buffermode = 2
        readfactor = 10
        tcptimeout = 15
    else:
        buffermode = 2
        readfactor = 20
        tcptimeout = 10

    curlclienttimeout = 10
    curllowspeedtime = 20
    curlretries = 2

    choice = dialog.yesno(AddonTitle, 'Com base na memória livre, o buffer ideal é: \n' +
                          str(memorysize) + ' Bytes (' + str(round(free_mem / 3)) + ' MB)\n' +
                          'As configurações avançadas serão sobrescritas.\n\nDeseja aplicar automaticamente?',
                          yeslabel='Aplicar', nolabel='Inserir manualmente')

    if choice == 1:
        xml_data = xml_data_advSettings_New(memorysize, curlclienttimeout, curllowspeedtime,
                                            curlretries, tcptimeout, buffermode, readfactor)
        with open(XML_FILE, "w") as f:
            f.write(xml_data)
        dialog.ok(AddonTitle, 'Configurações aplicadas. Reinicie o Kodi para que tenham efeito.')

    elif choice == 0:
        input_value = _get_keyboard(default=str(memorysize),
                                    heading="INSIRA O TAMANHO DO BUFFER EM BYTES ou ESC para cancelar",
                                    cancel="-")
        if input_value != "-":
            try:
                memorysize = int(input_value)
            except:
                dialog.ok(AddonTitle, "Valor inválido inserido.")
                return
            xml_data = xml_data_advSettings_New(memorysize, curlclienttimeout, curllowspeedtime,
                                                curlretries, tcptimeout, buffermode, readfactor)
            with open(XML_FILE, "w") as f:
                f.write(xml_data)
            dialog.ok(AddonTitle, 'Configurações aplicadas. Reinicie o Kodi para que tenham efeito.')

def open_Settings():
    open_Settings = xbmcaddon.Addon(id=AddonID).openSettings()

def _get_keyboard(default="", heading="", hidden=False, cancel=""):
    """ shows a keyboard and returns a value """
    if cancel == "":
        cancel = default
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        return unicode(keyboard.getText())
    return cancel

##############################    END    #########################################