# -*- coding: utf-8 -*-
import socket
import sys
import logging
import requests

addon_id = 'script.module.netunblock'
PY2 = sys.version_info[0] == 2
if PY2:
    from urlparse import urlparse
else:
    from urllib.parse import urlparse

logging.basicConfig(level=logging.DEBUG)
# Silencia logs do requests e urllib3
logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)


def get_doh_url():
    """
    Retorna a URL DoH configurada no ambiente.
    Se não estiver configurada, retorna a URL padrão.
    """
    from kodi_six import xbmcaddon
    addon = xbmcaddon.Addon(addon_id)
    doh_url = addon.getSetting("doh_url")
    return doh_url.strip()


def get_mode():
    """
    Retorna o modo de operação do addon.
    """
    from kodi_six import xbmcaddon
    addon = xbmcaddon.Addon(addon_id)
    mode = addon.getSetting("debug_mode")
    return mode == "true"


class DNSOverrideDoH:
    def __init__(self):
        from kodi_six import xbmcaddon
        self.addon = xbmcaddon.Addon(addon_id)
        doh_url = get_doh_url().strip().rstrip('/')
        self.debug_mode = False
        self.mode_logger = get_mode()

        # Detecta o modo baseado na URL ("/dns-query" = RFC8484)
        self.is_rfc8484 = '/dns-query' in doh_url

        if self.is_rfc8484:
            self.doh_url = doh_url  # ex: https://example.com/dns-query
        else:
            self.doh_url = doh_url + "/resolve?domain="  # ex: https://example.com/resolve?domain=

        self.original_getaddrinfo = socket.getaddrinfo
        self.cache = {}

        # Override DNS
        socket.getaddrinfo = self._resolver

    def is_valid_ipv4(self, ip):
        try:
            socket.inet_aton(ip)
            return True
        except socket.error:
            return False

    def resolve(self, domain):
        if domain in self.cache:
            if self.mode_logger:
                logging.info("Cache hit for {0}: {1}".format(domain, self.cache[domain]))
            return self.cache[domain]

        try:
            domain_target = domain.strip(".")

            if self.is_rfc8484:
                # Modo RFC 8484 (/dns-query)
                headers = {"Accept": "application/dns-json"}
                params = {"name": domain_target, "type": "A"}
                if self.mode_logger:
                    logging.debug("Resolving via DoH (RFC 8484): %s", self.doh_url)
                response = requests.get(self.doh_url, headers=headers, params=params, timeout=5)
                if response.status_code == 200:
                    data = response.json()
                    answers = data.get("Answer", [])
                    for answer in answers:
                        ip = answer.get("data")
                        if ip and self.is_valid_ipv4(ip):
                            self.cache[domain] = ip
                            return ip
            else:
                # Modo simples personalizado (/resolve?domain=...)
                url_dns = self.doh_url + domain_target
                if self.mode_logger:
                    logging.debug("Resolving via custom DoH: %s", url_dns)
                response = requests.get(url_dns, timeout=5)
                if response.status_code == 200:
                    data = response.json()
                    ip = data.get("ip")
                    if ip:
                        self.cache[domain] = ip
                        return ip
            return None
        except Exception as e:
            if self.mode_logger:
                logging.error("Erro ao resolver %s via DoH: %s", domain, e)
            return None

    def _resolver(self, host, port, *args, **kwargs):
        try:
            if self.doh_url and host in self.doh_url:
                return self.original_getaddrinfo(host, port, *args, **kwargs)

            if self.is_valid_ipv4(host):
                if self.mode_logger:
                    logging.debug("Bypass DNS: %s já é um IP", host)
                return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (host, port))]

            ip = self.resolve(host)
            if ip:
                return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (ip, port))]

            if self.mode_logger:
                logging.warning("Falha ao resolver %s, usando getaddrinfo original", host)

            if not self.debug_mode:
                return self.original_getaddrinfo(host, port, *args, **kwargs)
        except Exception as e:
            if self.mode_logger:
                logging.error("Erro no resolver para %s: %s", host, e)

        if not self.debug_mode:
            return self.original_getaddrinfo(host, port, *args, **kwargs)
